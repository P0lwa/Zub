# Djama — version 2

Trois dossiers, à publier dans trois dépôts GitHub **et à garder côte à côte** sur votre ordinateur :

```
djama-backend/    API ASP.NET Core + SignalR + EF Core + tests + docker-compose.yml
djama-frontend/   React (Vite) + Dockerfile + nginx
djama-docs/       contrats d'API, ERD, cas d'usage, tâches de chacun (team-tasks.ru.md)
```

## Lancer (Docker)
```bash
cd djama-backend
cp .env.example .env
docker compose up --build
```
Site : http://localhost — Swagger : http://localhost/swagger

## Lancer en développement (sans Docker pour l'API et le site)
```bash
cd djama-backend && docker compose up db -d          # PostgreSQL seul
dotnet run --project src/Djama.Api                    # API sur :8080
cd ../djama-frontend && npm install && npm run dev    # site sur :5173
```

## Nouveautés de la v2
Ajout de membres par recherche, messages vocaux, photos/documents/vidéos, réponses et modification de messages,
appels vocaux et vidéo 1-à-1 (WebRTC), nouvelle interface (barre de navigation, thème sombre, filtres), notifications flottantes.
Voir `UPGRADE-v2.md` pour la mise à jour depuis la v1 et `djama-docs/team-tasks-v2.ru.md` pour les tâches.

## Ce qui fonctionnait déjà en v1
Inscription/connexion (JWT), profil, recherche, contacts, blocage, discussions privées et groupes (rôles admin/membre),
messages en temps réel (SignalR), statuts ✓/✓✓, « écrit… », présence en ligne, réactions, suppression, notifications
des messages manqués, historique paginé, interface en russe et en français, tests unitaires du service de chat.

## À lire en premier
`djama-docs/team-tasks.ru.md` : ce que chacun développe ensuite. `djama-docs/api-contracts.md` : noms exacts des champs,
des routes et des événements (à modifier backend + frontend + document dans la même pull request).
