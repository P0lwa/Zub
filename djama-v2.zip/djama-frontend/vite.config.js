import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

// Dev: `npm run dev` -> http://localhost:5173, API + SignalR are proxied to the backend on :8080 (no CORS needed).
const api = 'http://localhost:8080';
export default defineConfig({
  plugins: [react()],
  server: {
    port: 5173,
    proxy: {
      '/api': api,
      '/swagger': api,
      '/hubs': { target: api, ws: true },
    },
  },
});
