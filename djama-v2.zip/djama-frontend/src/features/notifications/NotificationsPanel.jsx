// Owner: P4. "Missed message" and "added to group" notifications.
import { useChat } from '../chat/ChatContext';
import { useI18n } from '../../shared/i18n';
import { formatTime } from '../../shared/ui';

export default function NotificationsPanel({ onOpenChat }) {
  const { t } = useI18n();
  const { notifications, readNotification, readAllNotifications, openConversation } = useChat();

  const open = (n) => {
    readNotification(n);
    if (n.conversationId) { openConversation(n.conversationId); onOpenChat(); }
  };
  const text = (n) => (n.type === 'NewMessage' ? `${n.title}: ${n.body}` : `${t('notif.' + n.type)} « ${n.body} » — ${n.title}`);

  return (
    <div className="list">
      {notifications.some((n) => !n.isRead) && <button className="btn ghost block" onClick={readAllNotifications}>{t('notif.readAll')}</button>}
      {notifications.length === 0 && <p className="hint">{t('notif.empty')}</p>}
      {notifications.map((n) => (
        <button key={n.id} className={'row notif' + (n.isRead ? '' : ' unread')} onClick={() => open(n)}>
          <span className="row-main">
            <span className="row-top"><strong>{t('notif.' + n.type)}</strong><time>{formatTime(n.createdAt)}</time></span>
            <span className="preview">{text(n)}</span>
          </span>
        </button>
      ))}
    </div>
  );
}
