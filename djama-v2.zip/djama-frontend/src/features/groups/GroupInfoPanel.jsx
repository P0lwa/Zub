// Owner: P4. Members, roles, rename, ADD MEMBERS (search any user), remove, leave.
import { useEffect, useState } from 'react';
import { conversationsApi } from '../../shared/api/endpoints';
import { useAuth } from '../auth/AuthContext';
import { useChat } from '../chat/ChatContext';
import { errText, useI18n } from '../../shared/i18n';
import { Avatar } from '../../shared/ui';
import { Icon } from '../../shared/icons';
import UserPicker from '../../shared/UserPicker';

export default function GroupInfoPanel({ conversation, onClose }) {
  const { t } = useI18n();
  const { user } = useAuth();
  const { refreshConversations } = useChat();
  const [title, setTitle] = useState(conversation.title);
  const [adding, setAdding] = useState(false);
  const [selected, setSelected] = useState([]);
  const [err, setErr] = useState('');
  const isAdmin = conversation.members.some((m) => m.user.id === user.id && m.role === 'Admin');

  useEffect(() => setTitle(conversation.title), [conversation.title]);

  const run = async (fn) => {
    setErr('');
    try { await fn(); await refreshConversations(); } catch (e) { setErr(errText(t, e)); }
  };
  const toggle = (u) => setSelected((s) => (s.some((x) => x.id === u.id) ? s.filter((x) => x.id !== u.id) : [...s, u]));
  const addSelected = () => run(async () => {
    for (const u of selected) await conversationsApi.addMember(conversation.id, u.id);
    setSelected([]);
    setAdding(false);
  });

  return (
    <aside className="info">
      <header><strong>{t('groups.info')}</strong><button className="icon" onClick={onClose} aria-label={t('common.close')}><Icon.X size={20} /></button></header>
      <div className="info-hero"><Avatar name={conversation.title} size={84} /><h3>{conversation.title}</h3></div>
      {isAdmin && (
        <form className="inline" onSubmit={(e) => { e.preventDefault(); run(() => conversationsApi.rename(conversation.id, title)); }}>
          <input value={title} onChange={(e) => setTitle(e.target.value)} maxLength={64} required />
          <button className="btn small">{t('groups.rename')}</button>
        </form>
      )}
      {err && <p className="error" role="alert">{err}</p>}

      {isAdmin && !adding && (
        <button className="btn block" onClick={() => setAdding(true)}><Icon.UserPlus size={16} /> {t('groups.addMember')}</button>
      )}
      {isAdmin && adding && (
        <div className="add-box">
          <UserPicker selected={selected} onToggle={toggle} excludeIds={conversation.members.map((m) => m.user.id)} />
          <div className="modal-actions">
            <button className="btn small" onClick={() => { setAdding(false); setSelected([]); }}>{t('common.cancel')}</button>
            <button className="btn small primary" disabled={selected.length === 0} onClick={addSelected}>{t('groups.addSelected')}</button>
          </div>
        </div>
      )}

      <h3>{t('groups.members')} ({conversation.members.length})</h3>
      {conversation.members.map((m) => (
        <div key={m.user.id} className="row static">
          <Avatar name={m.user.displayName} online={m.user.isOnline} size={38} />
          <span className="row-main"><strong>{m.user.displayName}{m.user.id === user.id ? ' •' : ''}</strong>{m.role === 'Admin' && <span className="tag">{t('groups.admin')}</span>}</span>
          {isAdmin && m.user.id !== user.id && (
            <span className="actions">
              <button className="btn small" onClick={() => run(() => conversationsApi.setRole(conversation.id, m.user.id, m.role === 'Admin' ? 'Member' : 'Admin'))}>
                {m.role === 'Admin' ? t('groups.makeMember') : t('groups.makeAdmin')}
              </button>
              <button className="btn small danger" onClick={() => run(() => conversationsApi.removeMember(conversation.id, m.user.id))}>{t('groups.remove')}</button>
            </span>
          )}
        </div>
      ))}
      <button className="btn danger block" onClick={() => run(() => conversationsApi.removeMember(conversation.id, user.id))}><Icon.LogOut size={16} /> {t('groups.leave')}</button>
    </aside>
  );
}
