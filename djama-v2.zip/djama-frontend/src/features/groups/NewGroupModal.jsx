// Owner: P4. Create a group: pick people from your contacts OR search any user by name / username.
import { useState } from 'react';
import { useChat } from '../chat/ChatContext';
import { errText, useI18n } from '../../shared/i18n';
import UserPicker from '../../shared/UserPicker';

export default function NewGroupModal({ onClose, onCreated }) {
  const { t } = useI18n();
  const { createGroup } = useChat();
  const [title, setTitle] = useState('');
  const [selected, setSelected] = useState([]);
  const [err, setErr] = useState('');
  const [busy, setBusy] = useState(false);
  const toggle = (u) => setSelected((s) => (s.some((x) => x.id === u.id) ? s.filter((x) => x.id !== u.id) : [...s, u]));

  const submit = async (e) => {
    e.preventDefault();
    setBusy(true); setErr('');
    try { await createGroup(title, selected.map((u) => u.id)); onCreated(); onClose(); }
    catch (ex) { setErr(errText(t, ex)); } finally { setBusy(false); }
  };

  return (
    <div className="modal-back" onClick={onClose}>
      <form className="modal" onClick={(e) => e.stopPropagation()} onSubmit={submit}>
        <h2>{t('groups.new')}</h2>
        <label>{t('groups.title')}<input value={title} onChange={(e) => setTitle(e.target.value)} maxLength={64} required autoFocus /></label>
        <h3>{t('groups.members')} ({selected.length})</h3>
        <UserPicker selected={selected} onToggle={toggle} />
        {err && <p className="error" role="alert">{err}</p>}
        <div className="modal-actions">
          <button type="button" className="btn" onClick={onClose}>{t('common.cancel')}</button>
          <button className="btn primary" disabled={busy || !title.trim()}>{t('groups.create')}</button>
        </div>
      </form>
    </div>
  );
}
