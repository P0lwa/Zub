// Owner: P4. Search people, manage contacts and the block list.
import { useCallback, useEffect, useState } from 'react';
import { blocksApi, contactsApi, usersApi } from '../../shared/api/endpoints';
import { useChat } from '../chat/ChatContext';
import { errText, useI18n } from '../../shared/i18n';
import { Avatar } from '../../shared/ui';

function Person({ user, children }) {
  return (
    <div className="row static">
      <Avatar name={user.displayName} online={user.isOnline} />
      <span className="row-main"><strong>{user.displayName}</strong><span className="preview">@{user.username}</span></span>
      <span className="actions">{children}</span>
    </div>
  );
}

export default function ContactsPanel({ onOpenChat }) {
  const { t } = useI18n();
  const { startDirect } = useChat();
  const [q, setQ] = useState('');
  const [results, setResults] = useState([]);
  const [contacts, setContacts] = useState([]);   // ContactDto[]
  const [blocked, setBlocked] = useState([]);     // UserDto[]
  const [err, setErr] = useState('');

  const load = useCallback(async () => {
    const [c, b] = await Promise.all([contactsApi.list(), blocksApi.list()]);
    setContacts(c); setBlocked(b);
  }, []);

  useEffect(() => { load().catch((e) => setErr(errText(t, e))); }, [load]);   // eslint-disable-line react-hooks/exhaustive-deps
  useEffect(() => {
    if (q.trim().length < 2) { setResults([]); return undefined; }
    const h = setTimeout(() => usersApi.search(q).then(setResults).catch(() => {}), 300);
    return () => clearTimeout(h);
  }, [q]);

  const run = async (fn) => {
    setErr('');
    try { await fn(); await load(); } catch (e) { setErr(errText(t, e)); }
  };
  const isContact = (id) => contacts.some((c) => c.user.id === id);
  const message = (id) => run(async () => { await startDirect(id); onOpenChat(); });

  return (
    <div className="list">
      <input className="search" value={q} onChange={(e) => setQ(e.target.value)} placeholder={t('contacts.search')} />
      {err && <p className="error" role="alert">{err}</p>}
      {results.map((u) => (
        <Person key={u.id} user={u}>
          {!isContact(u.id) && <button className="btn small" onClick={() => run(() => contactsApi.add(u.id))}>{t('contacts.add')}</button>}
          <button className="btn small primary" onClick={() => message(u.id)}>{t('contacts.message')}</button>
        </Person>
      ))}

      <h3>{t('contacts.list')}</h3>
      {contacts.length === 0 && <p className="hint">{t('contacts.none')}</p>}
      {contacts.map(({ user }) => (
        <Person key={user.id} user={user}>
          <button className="btn small primary" onClick={() => message(user.id)}>{t('contacts.message')}</button>
          <button className="btn small" onClick={() => run(() => contactsApi.remove(user.id))}>{t('contacts.remove')}</button>
          <button className="btn small danger" onClick={() => run(() => blocksApi.block(user.id))}>{t('contacts.block')}</button>
        </Person>
      ))}

      {blocked.length > 0 && <h3>{t('contacts.blocked')}</h3>}
      {blocked.map((u) => (
        <Person key={u.id} user={u}>
          <button className="btn small" onClick={() => run(() => blocksApi.unblock(u.id))}>{t('contacts.unblock')}</button>
        </Person>
      ))}
    </div>
  );
}
