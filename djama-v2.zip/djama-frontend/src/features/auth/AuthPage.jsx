import { useState } from 'react';
import { useAuth } from './AuthContext';
import { errText, useI18n } from '../../shared/i18n';

export default function AuthPage() {
  const { t, lang, setLang } = useI18n();
  const { login, register } = useAuth();
  const [mode, setMode] = useState('login');
  const [f, setF] = useState({ usernameOrEmail: '', username: '', displayName: '', email: '', password: '' });
  const [err, setErr] = useState('');
  const [busy, setBusy] = useState(false);
  const set = (k) => (e) => setF({ ...f, [k]: e.target.value });

  const submit = async (e) => {
    e.preventDefault();
    setErr(''); setBusy(true);
    try {
      if (mode === 'login') await login({ usernameOrEmail: f.usernameOrEmail, password: f.password });
      else await register({ username: f.username, displayName: f.displayName, email: f.email, password: f.password });
    } catch (ex) { setErr(errText(t, ex)); } finally { setBusy(false); }
  };

  return (
    <div className="auth">
      <section className="auth-brand">
        <img src="/djama-logo.svg" alt="Djama" />
        <h1>Djama</h1>
        <p>{t('app.tagline')}</p>
      </section>
      <section className="auth-form">
        <form onSubmit={submit}>
          <h2>{mode === 'login' ? t('auth.login') : t('auth.register')}</h2>
          {mode === 'login' ? (
            <label>{t('auth.usernameOrEmail')}<input value={f.usernameOrEmail} onChange={set('usernameOrEmail')} autoComplete="username" required /></label>
          ) : (
            <>
              <label>{t('auth.username')}<input value={f.username} onChange={set('username')} autoComplete="username" required /></label>
              <label>{t('auth.displayName')}<input value={f.displayName} onChange={set('displayName')} required /></label>
              <label>{t('auth.email')}<input type="email" value={f.email} onChange={set('email')} autoComplete="email" required /></label>
            </>
          )}
          <label>{t('auth.password')}<input type="password" value={f.password} onChange={set('password')} autoComplete={mode === 'login' ? 'current-password' : 'new-password'} required /></label>
          {err && <p className="error" role="alert">{err}</p>}
          <button className="btn primary" disabled={busy}>{mode === 'login' ? t('auth.login') : t('auth.register')}</button>
          <p className="switch">
            {mode === 'login' ? t('auth.noAccount') : t('auth.haveAccount')}{' '}
            <button type="button" className="link" onClick={() => { setErr(''); setMode(mode === 'login' ? 'register' : 'login'); }}>
              {mode === 'login' ? t('auth.register') : t('auth.login')}
            </button>
          </p>
          <p className="switch">
            <button type="button" className="link" onClick={() => setLang(lang === 'ru' ? 'fr' : 'ru')}>{lang === 'ru' ? 'Français' : 'Русский'}</button>
          </p>
        </form>
      </section>
    </div>
  );
}
