import { createContext, useContext, useEffect, useState } from 'react';
import { authApi } from '../../shared/api/endpoints';
import { tokenStore } from '../../shared/api/client';

const AuthContext = createContext(null);
export const useAuth = () => useContext(AuthContext);

export function AuthProvider({ children }) {
  const [user, setUser] = useState(null);   // UserDto of the logged-in person
  const [ready, setReady] = useState(false);

  useEffect(() => {
    if (!tokenStore.get()) { setReady(true); return; }
    authApi.me().then(setUser).catch(() => tokenStore.clear()).finally(() => setReady(true));
  }, []);

  useEffect(() => {
    const onUnauthorized = () => { tokenStore.clear(); setUser(null); };
    window.addEventListener('djama:unauthorized', onUnauthorized);
    return () => window.removeEventListener('djama:unauthorized', onUnauthorized);
  }, []);

  const finish = (r) => { tokenStore.set(r.token); setUser(r.user); };
  const value = {
    user, ready, setUser,
    login: async (data) => finish(await authApi.login(data)),
    register: async (data) => finish(await authApi.register(data)),
    logout: () => { tokenStore.clear(); setUser(null); },
  };
  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}
