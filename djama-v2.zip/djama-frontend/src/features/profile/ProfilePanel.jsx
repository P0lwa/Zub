// Owner: P4. Edit my profile, choose language and theme, log out.
import { useState } from 'react';
import { usersApi } from '../../shared/api/endpoints';
import { useAuth } from '../auth/AuthContext';
import { LANGS, errText, useI18n } from '../../shared/i18n';
import { useTheme } from '../../shared/theme';
import { Avatar } from '../../shared/ui';
import { Icon } from '../../shared/icons';

export default function ProfilePanel() {
  const { t, lang, setLang } = useI18n();
  const { theme, setTheme } = useTheme();
  const { user, setUser, logout } = useAuth();
  const [displayName, setDisplayName] = useState(user.displayName);
  const [about, setAbout] = useState(user.about || '');
  const [msg, setMsg] = useState('');
  const [err, setErr] = useState('');

  const save = async (e) => {
    e.preventDefault();
    setErr(''); setMsg('');
    try { setUser(await usersApi.updateMe({ displayName, about })); setMsg(t('profile.saved')); }
    catch (ex) { setErr(errText(t, ex)); }
  };

  return (
    <form className="list profile" onSubmit={save}>
      <div className="me"><Avatar name={user.displayName} size={72} /><div><strong>{user.displayName}</strong><span className="preview">@{user.username}</span></div></div>
      <label>{t('auth.displayName')}<input value={displayName} onChange={(e) => setDisplayName(e.target.value)} maxLength={64} required /></label>
      <label>{t('profile.about')}<textarea rows={3} value={about} onChange={(e) => setAbout(e.target.value)} maxLength={256} /></label>
      {err && <p className="error" role="alert">{err}</p>}
      {msg && <p className="ok" role="status">{msg}</p>}
      <button className="btn primary">{t('profile.save')}</button>
      <label>{t('profile.language')}
        <select value={lang} onChange={(e) => setLang(e.target.value)}>
          {Object.entries(LANGS).map(([k, v]) => <option key={k} value={k}>{v}</option>)}
        </select>
      </label>
      <label>{t('profile.theme')}
        <select value={theme} onChange={(e) => setTheme(e.target.value)}>
          {['system', 'light', 'dark'].map((k) => <option key={k} value={k}>{t('theme.' + k)}</option>)}
        </select>
      </label>
      <button type="button" className="btn danger" onClick={logout}><Icon.LogOut size={16} /> {t('profile.logout')}</button>
    </form>
  );
}
