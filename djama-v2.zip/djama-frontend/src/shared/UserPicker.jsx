// Search ANY user (not only contacts). Shows my contacts until you type 2+ characters.
import { useEffect, useState } from 'react';
import { contactsApi, usersApi } from './api/endpoints';
import { useI18n } from './i18n';
import { Avatar } from './ui';
import { Icon } from './icons';

export default function UserPicker({ selected, onToggle, excludeIds = [] }) {
  const { t } = useI18n();
  const [q, setQ] = useState('');
  const [results, setResults] = useState([]);
  const [contacts, setContacts] = useState([]);
  const searching = q.trim().length >= 2;

  useEffect(() => { contactsApi.list().then((c) => setContacts(c.map((x) => x.user))).catch(() => {}); }, []);
  useEffect(() => {
    if (!searching) { setResults([]); return undefined; }
    const h = setTimeout(() => usersApi.search(q).then(setResults).catch(() => {}), 250);
    return () => clearTimeout(h);
  }, [q, searching]);

  const list = (searching ? results : contacts).filter((u) => !excludeIds.includes(u.id));
  const isSelected = (id) => selected.some((u) => u.id === id);

  return (
    <div className="picker">
      {selected.length > 0 && (
        <div className="chips">
          {selected.map((u) => (
            <button type="button" key={u.id} className="chip on" onClick={() => onToggle(u)}>{u.displayName} <Icon.X size={12} /></button>
          ))}
        </div>
      )}
      <label className="search-box"><Icon.Search size={16} /><input value={q} onChange={(e) => setQ(e.target.value)} placeholder={t('groups.search')} /></label>
      <div className="picker-list">
        {list.length === 0 && <p className="hint">{searching ? t('groups.noneFound') : t('contacts.none')}</p>}
        {list.map((u) => (
          <button type="button" key={u.id} className={'row' + (isSelected(u.id) ? ' on' : '')} onClick={() => onToggle(u)}>
            <Avatar name={u.displayName} online={u.isOnline} size={38} />
            <span className="row-main"><strong>{u.displayName}</strong><span className="preview">@{u.username}</span></span>
            {isSelected(u.id) && <Icon.Check size={18} />}
          </button>
        ))}
      </div>
    </div>
  );
}
