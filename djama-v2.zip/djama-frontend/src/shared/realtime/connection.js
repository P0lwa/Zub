// SignalR connection to /hubs/chat. The JWT travels as ?access_token=... (browsers cannot set WebSocket headers).
//
// Client -> server (conn.invoke): SendMessage(conversationId, text) -> MessageDto | Typing(conversationId) | MarkRead(conversationId)
// Server -> client (conn.on)    : ReceiveMessage, MessagesRead, MessageDeleted, ReactionChanged, Typing,
//                                 PresenceChanged, ConversationChanged, NotificationReceived
import { HubConnectionBuilder, LogLevel } from '@microsoft/signalr';
import { tokenStore } from '../api/client';

export function createChatConnection() {
  return new HubConnectionBuilder()
    .withUrl('/hubs/chat', { accessTokenFactory: () => tokenStore.get() ?? '' })
    .withAutomaticReconnect([0, 2000, 5000, 10000, 30000])
    .configureLogging(LogLevel.Warning)
    .build();
}
