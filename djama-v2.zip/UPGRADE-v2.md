# Passer de la v1 à la v2 de Djama

Ordre conseillé : **1) committer la v1 telle quelle**, **2) quelques jours plus tard, committer la v2 sur une branche**.

## 1. Committer la v1 (maintenant)
Dans chaque dépôt (`djama-backend`, `djama-frontend`, `djama-docs`) :
```bash
git init -b main
git add .
git commit -m "feat: first version of Djama"
git remote add origin https://github.com/<organisation>/<depot>.git
git push -u origin main
```

## 2. Committer la v2 (plus tard)
1. Dans chaque dépôt, créez une branche : `git checkout -b feature/v2`
2. **Copiez le contenu** des dossiers de cette archive par-dessus les vôtres (mêmes noms : `djama-backend`, `djama-frontend`, `djama-docs`) en acceptant le remplacement. Ne supprimez pas votre fichier `.env`.
3. Vérifiez ce qui change : `git status` puis `git diff --stat`.
4. Committez par morceaux, **chacun ses fichiers** (le professeur regarde les commits de chacun) :
   - backend : `feat: voice messages and attachments`, `feat: audio and video calls (signaling)`, `feat: reply and edit messages`
   - frontend : `feat: new layout and dark theme`, `feat: voice recorder and player`, `feat: WebRTC calls UI`, `feat: add members to groups`
   - docs : `docs: API contracts v2`
5. `git push -u origin feature/v2`, puis ouvrez une **pull request** relue par un autre membre avant de fusionner dans `main`.

## 3. Lancer la v2 avec vos données de la v1
```bash
cd djama-backend
docker compose up --build
```
La base de la v1 est **mise à jour automatiquement** (nouvelles colonnes ajoutées sans rien perdre). Un nouveau volume `uploads` est créé pour les photos, fichiers et messages vocaux.
Pour repartir d'une base vide : `docker compose down -v`.

## 4. Test rapide de la v2 (10 minutes, deux fenêtres : une normale + une navigation privée, sur `http://localhost`)
- [ ] Créer un groupe, puis **Infos du groupe → Ajouter des membres** : chercher quelqu'un qui n'est pas dans vos contacts.
- [ ] Envoyer une photo (bouton trombone), un document, puis glisser-déposer un fichier dans la conversation.
- [ ] Envoyer un **message vocal** (bouton micro), l'écouter dans l'autre fenêtre.
- [ ] **Répondre** à un message et en **modifier** un (menu ⌄ sur le message).
- [ ] Lancer un **appel vocal**, puis un **appel vidéo** : accepter dans l'autre fenêtre ; vérifier le résumé d'appel dans la discussion.
- [ ] Refuser un appel, appeler un utilisateur déconnecté (« Appel manqué »).
- [ ] Basculer en **thème sombre** (icône lune dans la barre de gauche) et changer de langue (Profil).

## Important pour les appels
Le navigateur n'autorise le micro et la caméra que sur **`http://localhost`** ou en **HTTPS**. Entre deux ordinateurs différents (adresse IP du réseau), il faudra HTTPS : tâche de Sangaré (voir `djama-docs/team-tasks-v2.ru.md`). Pour deux réseaux différents, un serveur TURN est aussi nécessaire.
