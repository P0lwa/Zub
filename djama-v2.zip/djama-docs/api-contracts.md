# Djama — API contracts v2 (single source of truth)

If you rename something here, rename it in **backend** (`Dtos/Dtos.cs`) **and** **frontend** (`src/shared/api/endpoints.js`) in the same pull request.

## Conventions
- Base URL: `/api` (Vite proxy in dev, nginx in Docker). Swagger: `/swagger`. Health: `/health`.
- JSON is **camelCase**. IDs are GUID strings. Dates are ISO-8601 UTC (`2026-10-16T10:00:00.123Z`). Enums travel as strings.
- Auth: `Authorization: Bearer <jwt>` (token returned by login/register, stored in `localStorage` key `djama_token`).
- Errors: HTTP status + `{ "code": "...", "error": "human readable (English)" }`. The frontend translates `code` (`src/shared/i18n.jsx`, keys `err.<CODE>`).

| code | status | meaning |
|---|---|---|
| `VALIDATION` | 400 | invalid input (message says what to fix) |
| `INVALID_CREDENTIALS` | 401 | wrong login/password |
| `FORBIDDEN` | 403 | not a member / not an admin / not your message |
| `BLOCKED` | 403 | a block exists between the two users |
| `NOT_FOUND` | 404 | unknown user / conversation / message |
| `CONFLICT` | 409 | username or e-mail taken, already a member |
| `BUSY` | 409 | the person you call is already in a call |
| `OFFLINE` | 409 | the person you call is not connected (a "missed call" message is added to the chat) |

## DTOs
```jsonc
UserDto          { id, username, displayName, about, isOnline, lastSeenAt }
AuthResponse     { token, expiresAt, user: UserDto }
ContactDto       { user: UserDto, addedAt }
MemberDto        { user: UserDto, role: "Admin"|"Member", joinedAt }
ReactionDto      { emoji, count, userIds: [guid] }
AttachmentDto    { id, fileName, contentType, sizeBytes, durationMs|null }   // durationMs: voice notes only
ReplyPreviewDto  { id, senderName, text, kind, isDeleted }
CallInfoDto      { media: "Audio"|"Video", status: "Ended"|"Missed"|"Declined", seconds }
MessageDto       { id, conversationId, senderId, senderName, kind: "Text"|"Image"|"File"|"Voice"|"Call",
                   text, createdAt, editedAt|null, isDeleted, replyTo: ReplyPreviewDto|null, call: CallInfoDto|null,
                   reactions: [ReactionDto], readByUserIds: [guid], attachments: [AttachmentDto] }
                 // text = caption for Image/File, empty for Voice/Call
ConversationDto  { id, type: "Direct"|"Group", title, members: [MemberDto], lastMessage: MessageDto|null,
                   unreadCount, updatedAt }          // title = other person's name for Direct chats
NotificationDto  { id, type: "NewMessage"|"AddedToGroup"|"System", title, body, conversationId|null, isRead, createdAt }
```

## REST endpoints (all except register/login need the JWT)
| Method + path | Body → Response |
|---|---|
| `POST /api/auth/register` | `{ username, displayName, email, password }` → `AuthResponse` |
| `POST /api/auth/login` | `{ usernameOrEmail, password }` → `AuthResponse` |
| `GET /api/auth/me` | → `UserDto` |
| `GET /api/users/search?q=` (min 2 chars) | → `UserDto[]` |
| `GET /api/users/{id}` | → `UserDto` |
| `PUT /api/users/me` | `{ displayName, about }` → `UserDto` |
| `GET /api/contacts` | → `ContactDto[]` |
| `POST /api/contacts` | `{ userId }` → `ContactDto` |
| `DELETE /api/contacts/{userId}` | → 204 |
| `GET /api/blocks` | → `UserDto[]` |
| `POST /api/blocks` | `{ userId }` → `UserDto` (also removes the contact) |
| `DELETE /api/blocks/{userId}` | → 204 |
| `GET /api/conversations` | → `ConversationDto[]` (newest first) |
| `GET /api/conversations/{id}` | → `ConversationDto` |
| `POST /api/conversations/direct` | `{ userId }` → `ConversationDto` (get or create) |
| `POST /api/conversations/group` | `{ title, memberIds: [guid] }` → `ConversationDto` (creator = Admin) |
| `PUT /api/conversations/{id}` | `{ title }` → `ConversationDto` (admin) |
| `POST /api/conversations/{id}/members` | `{ userId }` → `ConversationDto` (admin) |
| `DELETE /api/conversations/{id}/members/{userId}` | → 204 (admin removes anyone; a member can remove self = leave) |
| `PUT /api/conversations/{id}/members/{userId}/role` | `{ role: "Admin"\|"Member" }` → `ConversationDto` (admin) |
| `GET /api/conversations/{id}/messages?before=<createdAt>&limit=50` | → `MessageDto[]` oldest→newest |
| `POST /api/conversations/{id}/messages` | `{ text, replyToId? }` → `MessageDto` (REST fallback of the hub) |
| `POST /api/conversations/{id}/read` | → 204 |
| `POST /api/conversations/{id}/attachments` | **multipart/form-data**: `files` (1–10, ≤ 25 MB each), `caption?`, `replyToId?`, `voice?` (`true` for a voice note), `durationMs?` → `MessageDto[]` (one message per file) |
| `GET /api/attachments/{id}` | the file (members only). `?access_token=<jwt>` is accepted here so `<img>`/`<audio>` can load it |
| `PUT /api/messages/{id}` | `{ text }` → `MessageDto` (author only, text/caption, within 15 minutes) |
| `DELETE /api/messages/{id}` | → 204 (own messages only, soft delete) |
| `PUT /api/messages/{id}/reaction` | `{ emoji }` → `ReactionDto[]` (same emoji again removes it) |
| `GET /api/notifications` | → `NotificationDto[]` (last 50) |
| `POST /api/notifications/{id}/read` · `POST /api/notifications/read-all` | → 204 |

Limits: text 1–4000 chars · username `^[a-z0-9_]{3,32}$` (stored lowercase) · displayName 1–64 · about ≤ 256 · group title 1–64 · password ≥ 6.

## SignalR — `/hubs/chat?access_token=<jwt>`
Client → server (`connection.invoke`):
- `SendMessage(conversationId, text, replyToId|null)` → `MessageDto` — saves, then broadcasts `ReceiveMessage` to every member (sender included)
- `Typing(conversationId)` · `MarkRead(conversationId)`
- Calls (private chats only): `CallInvite(conversationId, "Audio"|"Video")` → `callId` · `CallAccept(callId)` · `CallReject(callId)` · `CallEnd(callId)` · `CallSignal(callId, "offer"|"answer"|"candidate", payloadJson)`

Server → client (`connection.on`):
| Event | Payload |
|---|---|
| `ReceiveMessage` | `MessageDto` (also used for call summaries: `kind: "Call"`) |
| `MessageEdited` | `MessageDto` |
| `IncomingCall` | `{ callId, conversationId, caller: UserDto, media }` |
| `CallAccepted` | `{ callId }` |
| `CallSignal` | `{ callId, fromUserId, kind, payload }` (WebRTC offer / answer / ICE candidate, relayed as is) |
| `CallEnded` | `{ callId, reason: "Ended"\|"Missed"\|"Declined" }` |
| `MessagesRead` | `{ conversationId, userId, readAt }` |
| `MessageDeleted` | `{ conversationId, messageId }` |
| `ReactionChanged` | `{ conversationId, messageId, reactions: [ReactionDto] }` |
| `Typing` | `{ conversationId, userId }` |
| `PresenceChanged` | `{ userId, isOnline }` |
| `ConversationChanged` | `{ conversationId }` → the client reloads `GET /api/conversations` |
| `NotificationReceived` | `NotificationDto` |

Hub errors arrive as `"<CODE>: message"` (e.g. `BLOCKED: User is blocked`).

## Configuration variables
| Where | Name | Meaning |
|---|---|---|
| `.env` / compose | `DB_PASSWORD` | PostgreSQL password |
| `.env` / compose | `JWT_KEY` | ≥ 32 chars, secret |
| `.env` / compose | `WEB_PORT` | website port (default 80) |
| `.env` / compose | `USE_MIGRATIONS` | `true` once EF migrations exist |
| API config | `Storage:Path` (`Storage__Path`) · `Storage:MaxFileMb` | where uploads are stored (Docker volume `uploads`) · size limit per file (25) |
| API config | `ConnectionStrings:Default` · `Jwt:Key/Issuer/Audience/ExpireHours` · `Database:UseMigrations` | env form: `ConnectionStrings__Default`, `Jwt__Key`, `Database__UseMigrations` |
| frontend storage | `djama_token` · `djama_lang` · `djama_theme` | JWT · UI language (`ru`/`fr`) · theme (`light`/`dark`/`system`) |

## Who owns what in the frontend
`shared/api/*` and `features/chat/*` → P3 · `features/contacts|groups|notifications|profile/*` → P4 · Docker/nginx/CI → P5 · `Controllers/Dtos/Hubs` → P1 · `Domain/Data/Migrations` → P2.
