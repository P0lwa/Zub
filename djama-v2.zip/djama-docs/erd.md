# Djama — ERD (PostgreSQL, 10 tables)

```mermaid
erDiagram
    users ||--o{ contacts : "owns"
    users ||--o{ contacts : "is added as"
    users ||--o{ blocks : "blocks"
    users ||--o{ blocks : "is blocked"
    users ||--o{ conversation_members : "joins"
    conversations ||--|{ conversation_members : "has"
    conversations ||--o{ messages : "contains"
    users ||--o{ messages : "sends"
    messages ||--o{ message_reads : "read by"
    users ||--o{ message_reads : "reads"
    messages ||--o{ reactions : "gets"
    users ||--o{ reactions : "reacts"
    messages ||--o{ attachments : "has"
    users ||--o{ notifications : "receives"

    users {
        uuid id PK
        string username UK
        string email UK
        string display_name
        string about
        string password_hash
        timestamptz created_at
        timestamptz last_seen_at
    }
    contacts {
        uuid owner_id PK,FK
        uuid contact_user_id PK,FK
        timestamptz created_at
    }
    blocks {
        uuid blocker_id PK,FK
        uuid blocked_user_id PK,FK
        timestamptz created_at
    }
    conversations {
        uuid id PK
        string type "Direct | Group"
        string title "groups only"
        string direct_key UK "smallerId_largerId"
        uuid created_by_id
        timestamptz created_at
        timestamptz updated_at
    }
    conversation_members {
        uuid conversation_id PK,FK
        uuid user_id PK,FK
        string role "Admin | Member"
        timestamptz joined_at
    }
    messages {
        uuid id PK
        uuid conversation_id FK
        uuid sender_id FK
        string kind "Text | Image | File | Voice | Call"
        string text "caption for Image/File"
        uuid reply_to_id FK "self reference (quote)"
        timestamptz edited_at
        string call_media "Audio | Video"
        string call_status "Ended | Missed | Declined"
        int call_seconds
        bool is_deleted
        timestamptz created_at
    }
    message_reads {
        uuid message_id PK,FK
        uuid user_id PK,FK
        timestamptz read_at
    }
    reactions {
        uuid message_id PK,FK
        uuid user_id PK,FK
        string emoji
    }
    attachments {
        uuid id PK
        uuid message_id FK
        string file_name
        string content_type
        bigint size_bytes
        string storage_path
        int duration_ms "voice notes"
    }
    notifications {
        uuid id PK
        uuid user_id FK
        string type "NewMessage | AddedToGroup | System"
        string title
        string body
        uuid conversation_id
        bool is_read
        timestamptz created_at
    }
```

**Design choices (to explain at the defence)**
- v2: a call is not a table of its own. When it ends the server stores one `messages` row with `kind = Call` (media, status, duration), so call history lives in the chat. Calls in progress are kept in server memory (they never outlive the server).
- v2: the real column names in PostgreSQL are the C# property names in PascalCase (`"Kind"`, `"ReplyToId"`...); the snake_case names above are for readability.
- A group is a `conversations` row with `type = Group`; its members are `conversation_members` rows with a role. A direct chat is the same structure with two members, made unique by `direct_key`.
- Read status is stored per message and per reader (`message_reads`): the sender sees ✓ (sent) or ✓✓ (read by the other / by everybody in a group).
- Deleting a message is a *soft delete* (`is_deleted`, text emptied) so history, reactions and unread counters stay consistent.
- Index `messages(conversation_id, created_at)` makes paging of the history fast; `conversation_members(user_id)` makes "my conversations" fast.
