# Djama — развёртывание

## Требования
- Docker Desktop (Windows / macOS) или Docker Engine + Compose v2 (Linux).
- 4 ГБ свободной ОЗУ (контейнеры ограничены: `db` 256 МБ, `api` 512 МБ, `web` 128 МБ), 3 ГБ на диске.
- Три репозитория рядом: `djama-backend`, `djama-frontend`, `djama-docs`.

## Запуск
```bash
cd djama-backend
cp .env.example .env        # PowerShell: copy .env.example .env
docker compose up --build
```
Сайт: `http://localhost` · Swagger: `http://localhost/swagger` · проверка: `http://localhost/health`.
Первая сборка занимает 5–8 минут (скачиваются образы), следующие — быстрее.

## Переменные (`.env`)
| Переменная | Назначение |
|---|---|
| `DB_PASSWORD` | пароль PostgreSQL |
| `JWT_KEY` | секрет подписи токенов (не менее 32 символов; в продакшене — случайный) |
| `WEB_PORT` | порт сайта на машине (по умолчанию 80) |
| `USE_MIGRATIONS` | `true`, когда созданы миграции EF Core |

## Данные и тома
- `pgdata` — база данных; `uploads` — фото, файлы и голосовые сообщения.
- Остановить: `docker compose stop` · удалить контейнеры, **сохранив данные**: `docker compose down` · **удалить и данные**: `docker compose down -v`.
- Резервная копия базы: `docker compose exec db pg_dump -U djama djama > backup.sql`
- Восстановление: `docker compose exec -T db psql -U djama djama < backup.sql`

## Обновление с версии 1 на версию 2
`git pull` во всех трёх репозиториях, затем `docker compose up --build`. Новые столбцы добавляются автоматически (`DbUpgrade.cs`), данные сохраняются. Одновременно обновляйте backend и frontend.

## Звонки: HTTPS и TURN
- Браузер разрешает микрофон и камеру только на `http://localhost` или по **HTTPS**. Для проверки на двух компьютерах поднимите HTTPS (например, Caddy или nginx с сертификатом mkcert).
- Для участников из разных сетей нужен TURN-сервер (coturn); сейчас используется только публичный STUN (`CallContext.jsx`, константа `ICE`).

## Частые проблемы
| Симптом | Решение |
|---|---|
| порт 80 занят | в `.env`: `WEB_PORT=8081`, сайт на `http://localhost:8081` |
| `Database not ready` в логах API | подождать: API пробует подключиться 10 раз; проверить `docker compose ps` |
| сайт открывается, но чат «Переподключается» | проверить блок `/hubs/` в `nginx.conf` (заголовки Upgrade / Connection) |
| не грузятся фото | проверить том `uploads` и размер файла (до 25 МБ) |
| ошибка после смены схемы | `docker compose down -v` (сбросит данные) и запустить заново |
| логи | `docker compose logs -f api` |
